<?php
/*
Template Name: O nama
*/
get_header(); ?>


<?php
get_footer();
?>
