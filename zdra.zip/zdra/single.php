<?php
get_header();
while ( have_posts() ) :
	the_post();
?>


<?php
endwhile; // End of the loop.
get_footer();
