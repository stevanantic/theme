<?php
/*
Template Name: Pocetna
*/
get_header();
?>


<?php
get_footer();
?>
