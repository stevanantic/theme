<?php
/*
Template Name: Testimonials
*/
get_header(); ?>

<?php
get_footer();
?>
