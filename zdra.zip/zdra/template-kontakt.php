<?php
/*
Template Name: Kontakt
*/
get_header();
?>

<?php
get_footer();
?>
