<?php
if ( ! function_exists( 'theme_setup' ) ) :
	function theme_setup() {
		//odavde se menja >theme name<
		load_theme_textdomain( 'custom_theme', get_template_directory() . '/languages' );
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'widgets' );

		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'custom_theme' ),
		) );

		add_image_size( 'example_size', 500, 500, true );
	}
endif;
add_action( 'after_setup_theme', 'theme_setup' );

function theme_scripts() {
	wp_enqueue_style( 'custom_theme-style', get_template_directory_uri() . '/dist/css/app.css' );
	wp_enqueue_script( 'custom_theme-js', get_template_directory_uri() . '/dist/js/app.js', array(), '2020111', false );

}
add_action( 'wp_enqueue_scripts', 'theme_scripts' );


/*
================================================
Register Custom Navigation Walker
================================================
*/
// function register_navwalker(){
// 	require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';
// }
// add_action( 'after_setup_theme', 'register_navwalker' );

// register_nav_menus( array(
// 	'primary' => __( 'Top menu', 'custom_theme' ),
// 	'secondary' => __('Footer-menu', 'custom_theme'),
// ) );

// function prefix_modify_nav_menu_args( $args ) {
// 	return array_merge( $args, array(
// 		'walker' => new WP_Bootstrap_Navwalker(),
// 	) );
// }
// add_filter( 'wp_nav_menu_args', 'prefix_modify_nav_menu_args' );


/*
================================================
Remove WordPress menu from admin bar
================================================
*/
add_action( 'admin_bar_menu', 'remove_wp_logo', 999 );
function remove_wp_logo( $wp_admin_bar ) {
	$wp_admin_bar->remove_node( 'wp-logo' );
}

/*
================================================
Change WordPress Login Logo
================================================
*/
function my_login_logo() { ?>
	<style type="text/css">
	body.login{
		background: #192038 !important;
	}
	body.login #login {
	 padding: 12% 0 0 !important;
	}
	body.login div#login h1 a {
		background-image:  url('//localhost:3000/custom_theme/wp-content/themes/custom_theme/dist/images/svg/custom_theme-logo.svg');
		background-size: contain;
		height: 70px;
		margin: 0 auto 50px;
		width: 250px;
	}
	body.login form{
		background:transparent;
		border:none;
		padding:0 !important;
	}
	body.login label {
		color: #fff;
		opacity: 0.9;
	}
	body.login #nav, body.login #backtoblog {
		padding-left: 0px;
	}
	body.login #nav a,
	body.login #backtoblog a{
		color: #fff;
		opacity: 0.9;
	}
	body.login #nav a:hover,
	body.login #backtoblog a:hover{
		color: #ffcf57;
	}
	body.login form p, body.login form p:focus {
		border-color: transparent !important;
	}
	body.login form input#user_login, body.login form input#user_pass {
		background: transparent !important;
		border-radius: 0;
		border-top:none;
		border-right: none;
		border-left: none;
		color: #fff;
	}
	body.login form input#user_login:focus, body.login form input#user_pass:focus {
		border-top-color: transparent !important;
		border-bottom-color: #ffcf57 !important;
	}
	body.login.js.login-action-login.wp-core-ui.locale-en-us{
		outline:none !important;
	}
	.login #login_error,
	.login .message,
	.login .success {
		background: transparent !important;
		border-left: 4px solid #ffcf57 !important;
		border-bottom: 1px solid #ffcf57 !important;
		color: #fff;
		opacity: 0.9;
	}
}
</style>
<?php }
add_action( 'login_enqueue_scripts', 'my_login_logo' );
