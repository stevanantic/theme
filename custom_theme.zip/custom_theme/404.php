<?php
get_header();
?>
<div class="container">
    <div class="row">
        <div class="404-content col-12 text-center mx-auto w-100 h-100">
            <h1>404</h1>
            <h5>The page you are looking for was not found.</h5>
            <p><a href="<?php echo home_url(); ?>">Back Home</a></p>
        </div>
    </div>
</div>
<?php
//get_footer();
?>
